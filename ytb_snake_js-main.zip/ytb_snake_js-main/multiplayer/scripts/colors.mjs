// snake colors
export default  ["blue", "red", "yellow", "green", "orange", "purple", "pink", "brown"];

