export default [
    {
        left: 'ArrowLeft',
        up: 'ArrowUp',
        right: 'ArrowRight',
        down: 'ArrowDown',
        bomb: ' '
    },
    {
        left: 'a',
        up: 'w',
        right: 'd',
        down: 's',
        bomb: 'q'
    },
    {
        left: 'f',
        up: 't',
        right: 'h',
        down: 'g',
        bomb: 'r'
    },
    {
        left: 'j',
        up: 'i',
        right: 'l',
        down: 'k',
        bomb: 'u'
    },
];