# Javascript Snake Game
## An old-school snake game multiplayer online

# ytb_snake_js 
(original version from a youtube video linked below)
https://youtu.be/J42SZXS-_Qo

[![Build Status](https://travis-ci.org/joemccann/dillinger.svg?branch=master)](https://travis-ci.org/joemccann/dillinger)

Fatures:


Live demo here:
https://carubbi-snake.herokuapp.com/frontend/snake.html

 
## Features

- Online multiplayer up to 8 players in the same room.
- Local multiplayer game up to 4 players in the same keyboard.
- Multiple rooms to enjoy with your friends
 
## Installation

ytb_snake_js requires [Node.js](https://nodejs.org/) v12+ to run.

Install the dependencies and start the server.

```sh
cd ytb_snake_js 
npm i
npm start
```
 
## License

MIT

**Free Software, Hell Yeah!**
